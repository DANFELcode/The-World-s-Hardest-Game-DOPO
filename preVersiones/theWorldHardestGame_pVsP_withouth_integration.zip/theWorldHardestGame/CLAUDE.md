# CLAUDE.md — Quick reference for Claude sessions

## What this project is

Final project for Universidad ECI's "Desarrollo Orientado por Objetos" course (2026-1). Java/Swing implementation of "The World's Hardest Game" (called The DOPO Hardest Game), built incrementally over 4 delivery cycles.

The project is evaluated by peers and the professor on OOP principles: classes/objects, design, relationships, abstract classes, interfaces, exceptions, JUnit, GUI, collections, I/O, and design patterns.

## Important locations

- **Project root**: `C:\Users\Daniel Felipe\Documents\Daniel\Universidad\2026-1\DOPO\theWorldHardestGame\theWorldHardestGame\`
- **Source**: `src/domain/` and `src/presentation/` and `src/test/`
- **Level configs**: `resources/levels/level1.txt`, `level2.txt`
- **Documentation**: `..\info\` (CURRENT_STATE.md, DEADLINES.md, PHILOSOPHY.md, ARCHITECTURE.md, plus the PDF spec)
- **PDF spec**: `..\info\The DOPO Hardest Game 2026-01.pdf`

## Critical rules from PHILOSOPHY.md

1. Always require context before coding. Never guess missing requirements.
2. Modify only necessary parts. Avoid rewriting files unless requested.
3. Validate solutions before considering them complete.
4. Code is written in English (only user-facing presentation text may stay in Spanish).
5. **NEVER use `instanceof`**. It breaks polymorphism. Solve with method overriding.
6. When the user asks, they are not invalidating — they are asking. Answer directly without defending previous decisions.

## Domain rules from PDF (key constraints)

- Player speeds are **ratios** of UNIT: Red 1×, Blue 1.5×, Green 1× (weakened 0.7×). Blue is also 1.5× size.
- Enemy speeds: basic 1×, accelerated (Tipo A) 2×, patroller follows waypoints.
- Green player absorbs first hit with reduced speed, dies on second.
- SkinCoin gives player a temporary skin until death.
- Level completes when all coins collected + reach final zone before timer ends.

## Architecture highlights (post-refactor)

- **Domain** uses ticks (not seconds) for time. `UNIT = 4` is the only calibration constant. No `deltaTime`, no `TARGET_FPS`.
- **Presentation** controls real time via fixed-step accumulator in `GameLoop`. Translates ticks ↔ seconds at boundaries (loader, exporter, UI display).
- **Facade pattern**: GUI only talks to `TheDOPOHardestGame`. Never reaches into `Level` or other domain classes directly.
- **`TheDOPOHardestGame` is NOT a Singleton anymore** (was removed because it conflicted with `Serializable`). `GameDataAccess` and `GameLogger` remain Singleton (legitimate shared resources).
- **All collision logic is polymorphic** via `Interactable.onPlayerContact(Player, Level)`. No type-checks in `Level`.
- **Rendering is polymorphic** via `Drawable.toDrawCommand()`. `BoardPanel` only knows the facade and `DrawCommand`.
- **Skin behavior is Strategy pattern**: `SkinBehavior` interface with `apply/onHit/getDisplayColor`. Each Player subclass declares its `createDefaultSkin()`.

## Workflow

When the user asks for changes:
1. Read relevant files first.
2. Propose a plan with concrete impact (files to touch, trade-offs).
3. Wait for approval before editing — they prefer explicit confirmation over unilateral action.
4. After implementing, summarize what changed and what's pending.

The user has pushed back when changes are made without a plan ("deja de editar cosas sin haber definido previamente un plan").

## Things the user values

- **OOP correctness** over pragmatism, when in conflict. They want to defend the design against the professor.
- **Honest trade-off analysis** when there's no perfect answer.
- **Concise responses**. No fluff. PHILOSOPHY.md is strict on this.
- **Spanish for conversation, English for code**.

## See also

- `..\info\CURRENT_STATE.md` — comprehensive status of features and corrections applied
- `..\info\PHILOSOPHY.md` — strict project rules
- `..\info\DEADLINES.md` — delivery dates
