package domain;

import java.awt.Color;

/**
 * Represents a collectible coin in the game. <br>
 * <b>(x, y, width, height, collected)</b> <br>
 * <b>Inv:</b> width > 0 and height > 0
 */
public class Coin extends StaticElement implements Collectible {

    private boolean collected;

    /**
     * Creates a coin at the given position and size.
     * @param x horizontal position
     * @param y vertical position
     * @param width coin width, must be greater than 0
     * @param height coin height, must be greater than 0
     */
    public Coin(double x, double y, double width, double height, String color) {
        super(x, y, width, height, color);
        this.collected = false;
    }

    /**
     * Marks the coin as collected.
     * @param player the player that collected the coin
     */
    public void onCollect(Player player) {
    	player.collectCoin();
        if (!collected) this.collected = true;
    }

    @Override
    public void onContact(Player player, Level level) {
        onCollect(player);
    }

    /**
     * Returns whether this coin has been collected.
     * @return true if the coin has been collected
     */
    public boolean isCollected() {
        return collected;
    }

    public void reset() {
        this.collected = false;
    }

    /** Returns the coin's type identifier used in level files (e.g. "yellow", "blue"). */
    public String getCoinType() { return "yellow"; }
    
    public Color getDisplayColor() {
        return new Color(218, 165, 32);
    }

    @Override
    public DrawCommand toDrawCommand() {
        return new DrawCommand(getDisplayColor(), (int)getX(), (int)getY(), (int)getWidth(), (int)getHeight(), DrawCommand.Shape.OVAL);
    }
}