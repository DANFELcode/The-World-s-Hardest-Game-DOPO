package domain;

import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameDataAccess {
	private static final String LEVELS_PATH = "resources/levels/";
	private static GameDataAccess instance;
	
	
	private GameDataAccess() {
		
	}	
	
	
    public static GameDataAccess getInstance() {
        if (instance == null) {
        	instance = new GameDataAccess();
        	GameLogger.getInstance().logInfo("GameDataAccess inicializado");
        }
        
        return instance;
    }
    
    //convierte un array de strings en un mapa de pares clave-valor
    
    private Map<String, String> parseParams(String paramsStr) {
        Map<String, String> params = new HashMap<>();
        for (String pair : paramsStr.split(",")) {
            String[] keyValue = pair.split("=");
            if (keyValue.length == 2) {
                params.put(keyValue[0].trim(), keyValue[1].trim());
            }
        }
        return params;
    }
    
    public Level loadLevel(String file) {
    	Integer number = null;
        Double time = null;
        GameMap map = new GameMap(800, 500);
        List<String> elementLines = new ArrayList<>(); //todo lo que no sea configuración	
    	
    	try (
    		BufferedReader reader = new BufferedReader(
    				new FileReader(LEVELS_PATH + file))){
    		
    		String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                if (line.startsWith("NUMBER=")) {
                    number = Integer.parseInt(line.split("=")[1]);
                } else if (line.startsWith("TIME=")) {
                    time = Double.parseDouble(line.split("=")[1]);
                } else {
                    elementLines.add(line);
                }
            }
        } catch (IOException e) {
            GameLogger.getInstance().logError("Error leyendo nivel: " + file, e);
            return null;
        }
    	
        if (number == null || time == null) {
            try {
                throw new GameException("Faltan NUMBER o TIME en: " + file);
            } catch (GameException e) {
                GameLogger.getInstance().logError("Nivel inválido", e);
                return null;
            }
        }
        
        Level level = new Level(number, time, map);
        
        for (String elementLine: elementLines) {
        	int spaceIdx = elementLine.indexOf(' ');
        	String type = spaceIdx == -1 ? elementLine : elementLine.substring(0, spaceIdx);
        	Map<String, String> p = spaceIdx == -1
        	    ? new HashMap<>()
        	    : parseParams(elementLine.substring(spaceIdx + 1));
        	
        	
        	switch(type) {
	        	case "PLAYER":
	        		Player player;
	                switch (p.get("type")) {
	                case "blue":
	                    player = new BluePlayer("Player",
	                        Double.parseDouble(p.get("x")),
	                        Double.parseDouble(p.get("y")));
	                    break;
	                case "green":
	                    player = new GreenPlayer("Player",
	                        Double.parseDouble(p.get("x")),
	                        Double.parseDouble(p.get("y")));
	                    break;
	                default:
	                    player = new RedPlayer("Player",
	                        Double.parseDouble(p.get("x")),
	                        Double.parseDouble(p.get("y")));
	                    break;
	                }
	                level.addPlayer(player);
	                break;
	            
	            case "WALL":
	                level.addStaticElement(new SolidWall(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height")),
	                    "black"
	                ));
	                break;
	                
	            case "COIN":
	                if ("blue".equals(p.get("type")) || "green".equals(p.get("type")) || "red".equals(p.get("type"))) {
	                    level.addCoin(new SkinCoin(
	                        Double.parseDouble(p.get("x")),
	                        Double.parseDouble(p.get("y")),
	                        Double.parseDouble(p.get("width")),
	                        Double.parseDouble(p.get("height")),
	                        p.get("type")
	                    ));
	                } else {
	                    level.addCoin(new Coin(
	                        Double.parseDouble(p.get("x")),
	                        Double.parseDouble(p.get("y")),
	                        Double.parseDouble(p.get("width")),
	                        Double.parseDouble(p.get("height")),
	                        p.get("type")
	                    ));
	                }
	                break;
	                
	            case "ENEMY":
	                MovementStrategy movement;
	                String movementType = p.get("movement");
	                if ("patrol".equals(movementType)) {
	                    String[] points = p.get("route").split("\\|");
	                    Point2D.Double[] route = new Point2D.Double[points.length];
	                    for (int i = 0; i < points.length; i++) {
	                        String[] xy = points[i].split(":");
	                        route[i] = new Point2D.Double(
	                            Double.parseDouble(xy[0]),
	                            Double.parseDouble(xy[1])
	                        );
	                    }
	                    movement = PatrolMovement.basic(route);
	                } else {
	                    LinearMovement.Direction dir =
	                        LinearMovement.Direction.valueOf(p.get("direction"));
	                    int sign = Integer.parseInt(p.get("sign"));
	                    movement = "accelerated".equals(movementType)
	                        ? LinearMovement.accelerated(dir, sign)
	                        : LinearMovement.basic(dir, sign);
	                }
	                level.addEnemy(new Enemy(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height")),
	                    movement
	                ));
	                break;
	                
	            case "LIFESOURCE":
	                level.addStaticElement(new LifeSource(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height")),
	                    "yellow"
	                ));
	                break;

	            case "BOMB":
	                level.addStaticElement(new Bomb(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height"))
	                ));
	                break;
	                
	            case "INITIAL_ZONE":
	                level.addZone("initial", new InitialZone(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height"))
	                ));
	                break;

	            case "FINAL_ZONE":
	                level.addZone("final", new FinalZone(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height"))
	                ));
	                break;

	            case "INTERMEDIATE_ZONE":
	                level.addZone("intermediate", new IntermediateZone(
	                    Double.parseDouble(p.get("x")),
	                    Double.parseDouble(p.get("y")),
	                    Double.parseDouble(p.get("width")),
	                    Double.parseDouble(p.get("height"))
	                ));
	                break;
	                
	            default:
	                GameLogger.getInstance().logWarning(
	                    "Tipo desconocido en nivel: " + type);
	                break;
	        	}    		
    		}
        	
	        GameLogger.getInstance().logInfo("Nivel " + number + " cargado desde " + file);
	        return level;       
    
    	}
	}
