package domain;

import java.awt.Color;

public class SkinCoin extends Coin {

    private final String skinType;

    public SkinCoin(double x, double y, double width, double height, String color, String ownerName) {
        super(x, y, width, height, color, ownerName);
        this.skinType = color;
    }

    @Override
    public void onCollect(Player player) {
        boolean wasUncollected = !isCollected();
        super.onCollect(player);
        if (wasUncollected && isCollected()) {
            player.restoreSkin();
            player.changeSkin(SkinBehavior.of(skinType));
            player.setLastSkin(skinType);
        }
    }

    @Override
    public Color getDisplayColor() {
        return SkinBehavior.of(skinType).getDisplayColor();
    }

    @Override
    public String getCoinType() { return getColor(); }
}
